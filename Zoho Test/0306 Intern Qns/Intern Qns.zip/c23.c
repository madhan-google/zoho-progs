#include <stdio.h>
int main()
{
    int a = 7, b = 4;
    a = a + b + a;
    b = a - b;
    printf("%d ", b);
}
