#include<stdio.h>

int main()
{
    int a = 11, b = 4;
    a = a+b +b;
    b = a-b;
    printf("b = %d",b);
}